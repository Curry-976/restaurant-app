const orderId = new URLSearchParams(location.search).get("order");

const socket = new WebSocket("ws://localhost:8080");

socket.onopen = () => {
  socket.send(JSON.stringify({
    type: "join",
    order_id: orderId,
    role: "client"
  }));
};

socket.onmessage = (e) => {
  const d = JSON.parse(e.data);
  document.getElementById("status").innerText =
    `Livreur : ${d.lat}, ${d.lng}`;
};
