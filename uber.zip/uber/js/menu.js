(async () => {
  const dishes = await apiGet("/dishes/list.php");
  const menu = document.getElementById("menu");

  dishes.forEach(d => {
    const div = document.createElement("div");
    div.innerHTML = `
      <b>${d.name}</b> - ${d.price} €
      <button>Ajouter</button>
    `;
    div.querySelector("button").onclick = () =>
      apiPost("/cart/add.php", { dish_id: d.id, quantity: 1 });
    menu.appendChild(div);
  });
})();
