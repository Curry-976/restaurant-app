document.getElementById("pay").onclick = async () => {
  const customer_name = name.value;
  const address = address.value;

  const order = await apiPost("/orders/checkout.php", {
    customer_name, address
  });

  const payment = await apiPost("/payment/pay.php", {
    order_id: order.order_id,
    amount: 0 // (calculable côté serveur)
  });

  if (payment.status === "success") {
    location.href = "track.html?order=" + order.order_id;
  } else {
    alert("Paiement refusé");
  }
};
