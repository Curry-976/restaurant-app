const API = "/restaurant-app/api";

async function apiGet(url) {
  const res = await fetch(API + url, { credentials: "include" });
  return res.json();
}

async function apiPost(url, data) {
  const res = await fetch(API + url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    credentials: "include",
    body: JSON.stringify(data)
  });
  return res.json();
}
