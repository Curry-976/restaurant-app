(async () => {
  const items = await apiGet("/cart/view.php");
  const cart = document.getElementById("cart");
  let total = 0;

  items.forEach(i => {
    total += i.total;
    cart.innerHTML += `${i.name} x${i.quantity} = ${i.total} €<br>`;
  });

  cart.innerHTML += `<b>Total : ${total} €</b>`;
})();
