<?php
function deliveryFee($distance)
{
    if ($distance <= 2) return 2.00;
    if ($distance <= 4) return 4.00;
    if ($distance <= 5) return 6.00;

    return null; // hors zone
}
