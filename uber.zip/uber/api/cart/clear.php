<?php
session_start();
require "../role_check.php";

requireRole(["client"]);

unset($_SESSION["cart"]);

echo json_encode(["message" => "Panier vidé"]);
