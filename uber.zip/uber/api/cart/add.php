<?php
session_start();
require "../../config/db.php";
require "../role_check.php";

requireRole(["client"]);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["dish_id"], $data["quantity"])) {
    http_response_code(400);
    echo json_encode(["error" => "Données manquantes"]);
    exit;
}

$dishId = (int)$data["dish_id"];
$qty = (int)$data["quantity"];

if (!isset($_SESSION["cart"])) {
    $_SESSION["cart"] = [];
}

$_SESSION["cart"][$dishId] =
    ($_SESSION["cart"][$dishId] ?? 0) + $qty;

echo json_encode(["message" => "Plat ajouté au panier"]);
