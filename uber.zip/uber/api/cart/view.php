<?php
session_start();
require "../../config/db.php";
require "../role_check.php";

requireRole(["client"]);

$cart = $_SESSION["cart"] ?? [];
$result = [];

if ($cart) {
    $ids = implode(",", array_keys($cart));
    $stmt = $pdo->query(
        "SELECT id, name, price FROM dishes WHERE id IN ($ids)"
    );

    foreach ($stmt->fetchAll(PDO::FETCH_ASSOC) as $dish) {
        $dish["quantity"] = $cart[$dish["id"]];
        $dish["total"] = $dish["price"] * $dish["quantity"];
        $result[] = $dish;
    }
}

echo json_encode($result);
