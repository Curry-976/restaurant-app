<?php
session_start();
require "../role_check.php";

requireRole(["client"]);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["dish_id"])) {
    http_response_code(400);
    echo json_encode(["error" => "ID manquant"]);
    exit;
}

unset($_SESSION["cart"][$data["dish_id"]]);

echo json_encode(["message" => "Plat retiré"]);
