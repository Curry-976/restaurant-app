<?php
require "../../config/db.php";
require "../role_check.php";

requireRole(["admin", "client"]);

$stmt = $pdo->query(
    "SELECT * FROM dishes WHERE available = 1"
);

$dishes = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($dishes);
