<?php
require "../../config/db.php";
require "../role_check.php";

requireRole(["admin"]);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["id"], $data["name"], $data["price"], $data["available"])) {
    http_response_code(400);
    echo json_encode(["error" => "Données manquantes"]);
    exit;
}

$stmt = $pdo->prepare(
    "UPDATE dishes
     SET name = ?, price = ?, available = ?
     WHERE id = ?"
);

$stmt->execute([
    $data["name"],
    $data["price"],
    $data["available"],
    $data["id"]
]);

echo json_encode(["message" => "Plat modifié"]);
