<?php
require "../../config/db.php";
require "../role_check.php";

requireRole(["admin"]);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["name"], $data["price"])) {
    http_response_code(400);
    echo json_encode(["error" => "Données manquantes"]);
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO dishes (name, price, available)
     VALUES (?, ?, 1)"
);

$stmt->execute([
    $data["name"],
    $data["price"]
]);

echo json_encode(["message" => "Plat créé"]);
