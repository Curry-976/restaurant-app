<?php
require "../../config/db.php";
require "../role_check.php";

requireRole(["admin"]);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["id"])) {
    http_response_code(400);
    echo json_encode(["error" => "ID manquant"]);
    exit;
}

$stmt = $pdo->prepare(
    "UPDATE dishes SET available = 0 WHERE id = ?"
);

$stmt->execute([$data["id"]]);

echo json_encode(["message" => "Plat désactivé"]);
