<?php
require "../../utils/distance.php";
require "../../utils/delivery.php";
$config = require "../../config/restaurant.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["lat"], $data["lng"])) {
    http_response_code(400);
    echo json_encode(["error" => "Coordonnées manquantes"]);
    exit;
}

$distance = distanceKm(
    $config["lat"],
    $config["lng"],
    $data["lat"],
    $data["lng"]
);

$fee = deliveryFee($distance);

if ($fee === null || $distance > $config["max_distance_km"]) {
    echo json_encode([
        "deliverable" => false,
        "distance_km" => round($distance, 2)
    ]);
    exit;
}

echo json_encode([
    "deliverable" => true,
    "distance_km" => round($distance, 2),
    "delivery_fee" => $fee
]);
