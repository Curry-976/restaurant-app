<?php
session_start();
require "../../config/db.php";
require "../role_check.php";

requireRole(["client"]);

$cart = $_SESSION["cart"] ?? [];

if (!$cart) {
    http_response_code(400);
    echo json_encode(["error" => "Panier vide"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["customer_name"], $data["address"])) {
    http_response_code(400);
    echo json_encode(["error" => "Infos client manquantes"]);
    exit;
}

// 1️⃣ Créer commande
$stmt = $pdo->prepare(
    "INSERT INTO orders (customer_name, address, status)
     VALUES (?, ?, ?)"
);
$stmt->execute([
    $data["customer_name"],
    $data["address"],
    "pending"
]);

$orderId = $pdo->lastInsertId();

// 2️⃣ Insérer items
$itemStmt = $pdo->prepare(
    "INSERT INTO order_items (order_id, dish_id, quantity)
     VALUES (?, ?, ?)"
);

foreach ($cart as $dishId => $qty) {
    $itemStmt->execute([$orderId, $dishId, $qty]);
}

// 3️⃣ Vider panier
unset($_SESSION["cart"]);

echo json_encode([
    "message" => "Commande validée",
    "order_id" => $orderId
]);
