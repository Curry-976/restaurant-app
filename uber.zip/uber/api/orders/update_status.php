<?php
require "../../config/db.php";
require "../auth_check.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["order_id"], $data["status"])) {
    http_response_code(400);
    echo json_encode(["error" => "Paramètres manquants"]);
    exit;
}

$stmt = $pdo->prepare(
    "UPDATE orders SET status = ? WHERE id = ?"
);

$stmt->execute([
    $data["status"],
    $data["order_id"]
]);

echo json_encode(["message" => "Statut mis à jour"]);
