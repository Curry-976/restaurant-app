<?php
require "../../config/db.php";
require "../auth_check.php";

if ($_SESSION["role"] !== "admin") {
    http_response_code(403);
    echo json_encode(["error" => "Accès refusé"]);
    exit;
}

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["order_id"], $data["driver_id"])) {
    http_response_code(400);
    echo json_encode(["error" => "Paramètres manquants"]);
    exit;
}

$stmt = $pdo->prepare(
    "UPDATE orders
     SET driver_id = ?, status = ?
     WHERE id = ?"
);

$stmt->execute([
    $data["driver_id"],
    "delivering",
    $data["order_id"]
]);

echo json_encode(["message" => "Livreur assigné"]);
