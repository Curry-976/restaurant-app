<?php
require "../../config/db.php";
require "../auth_check.php";

$stmt = $pdo->query(
    "SELECT * FROM orders ORDER BY id DESC"
);

$orders = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($orders);
