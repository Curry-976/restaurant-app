<?php
require "../../config/db.php";
require "../auth_check.php";

$data = json_decode(file_get_contents("php://input"), true);

if (!$data || !isset($data["customer_name"], $data["address"], $data["items"])) {
    http_response_code(400);
    echo json_encode(["error" => "Données invalides"]);
    exit;
}

$stmt = $pdo->prepare(
    "INSERT INTO orders (customer_name, address, status)
     VALUES (?, ?, ?)"
);

$stmt->execute([
    $data["customer_name"],
    $data["address"],
    "pending"
]);

$orderId = $pdo->lastInsertId();

$itemStmt = $pdo->prepare(
    "INSERT INTO order_items (order_id, dish_id, quantity)
     VALUES (?, ?, ?)"
);

foreach ($data["items"] as $item) {
    $itemStmt->execute([
        $orderId,
        $item["dish_id"],
        $item["quantity"]
    ]);
}

echo json_encode([
    "message" => "Commande créée",
    "order_id" => $orderId
]);
