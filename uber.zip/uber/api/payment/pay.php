<?php
session_start();
require "../../config/db.php";
require "../role_check.php";

requireRole(["client"]);

$data = json_decode(file_get_contents("php://input"), true);

if (!isset($data["order_id"], $data["amount"])) {
    http_response_code(400);
    echo json_encode(["error" => "Données manquantes"]);
    exit;
}

$orderId = (int)$data["order_id"];
$amount = (float)$data["amount"];

// 🔮 SIMULATION
// 90% de chance de succès
$success = rand(1, 10) <= 9;

if ($success) {
    $stmt = $pdo->prepare(
        "UPDATE orders
         SET payment_status = ?, payment_method = ?, status = ?
         WHERE id = ?"
    );
    $stmt->execute([
        "paid",
        "mock",
        "preparing",
        $orderId
    ]);

    echo json_encode([
        "status" => "success",
        "message" => "Paiement accepté"
    ]);
} else {
    $stmt = $pdo->prepare(
        "UPDATE orders
         SET payment_status = ?
         WHERE id = ?"
    );
    $stmt->execute([
        "failed",
        $orderId
    ]);

    echo json_encode([
        "status" => "failed",
        "message" => "Paiement refusé"
    ]);
}
