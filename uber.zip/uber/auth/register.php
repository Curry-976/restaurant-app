<?php
require "../config/db.php";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $name = trim($_POST["name"]);
    $email = trim($_POST["email"]);
    $password = $_POST["password"];
    $role = "client"; // par défaut

    if (!$name || !$email || !$password) {
        die("Champs manquants");
    }

    // Vérifier email déjà utilisé
    $check = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $check->execute([$email]);

    if ($check->rowCount() > 0) {
        die("Email déjà utilisé");
    }

    // Hash du mot de passe
    $hash = password_hash($password, PASSWORD_DEFAULT);

    $stmt = $pdo->prepare(
        "INSERT INTO users (name, email, password, role)
         VALUES (?, ?, ?, ?)"
    );

    $stmt->execute([$name, $email, $hash, $role]);

    echo "✅ Inscription réussie";
}
