<?php
return [
    "lat" => 47.218371,   // exemple : Nantes
    "lng" => -1.553621,
    "max_distance_km" => 5
];
