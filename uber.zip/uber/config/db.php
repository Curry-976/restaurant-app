<?php

$host = $_ENV["dpg-d5uriit6ubrc73bvqm7g-a"];
$port = $_ENV["5432"];
$dbname = $_ENV["restaurant_app"];
$user = $_ENV["restaurant_app_jxd3_user"];
$password = $_ENV["uamydu3EKGeTH65LBSbPvcIsNQwCWcx6"];

try {
    $pdo = new PDO(
        "pgsql:host=$host;port=$port;dbname=$dbname",
        $user,
        $password,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC
        ]
    );
} catch (PDOException $e) {
    die("Erreur DB");
}
