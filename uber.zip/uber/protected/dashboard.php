<?php
session_start();

if (!isset($_SESSION["user_id"])) {
    header("Location: ../index.php");
    exit;
}
?>

<h1>Bienvenue <?= htmlspecialchars($_SESSION["name"]) ?></h1>
<p>Rôle : <?= $_SESSION["role"] ?></p>

<a href="../auth/logout.php">Déconnexion</a>
