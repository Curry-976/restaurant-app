<h2>Inscription</h2>
<form method="POST" action="auth/register.php">
    <input name="name" placeholder="Nom"><br>
    <input name="email" placeholder="Email"><br>
    <input type="password" name="password" placeholder="Mot de passe"><br>
    <button>S'inscrire</button>
</form>

<h2>Connexion</h2>
<form method="POST" action="auth/login.php">
    <input name="email" placeholder="Email"><br>
    <input type="password" name="password" placeholder="Mot de passe"><br>
    <button>Se connecter</button>
</form>
